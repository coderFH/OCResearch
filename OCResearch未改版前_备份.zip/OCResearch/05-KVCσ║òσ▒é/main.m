//
//  main.m
//  05-KVC底层
//
//  Created by Ne on 2018/7/15.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
