//
//  FHPerson.h
//  05-KVC底层
//
//  Created by Ne on 2018/7/15.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHPerson : NSObject {
@private
        int _age;
    //    int _isAge;
    //    int age;
    //    int isAge;
}
@end
