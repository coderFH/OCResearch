//
//  Target.m
//  43-适配器模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "Target.h"

@implementation Target

- (void)operation {
    //原有的具体业务逻辑
    NSLog(@"我是原来的业务逻辑");
}

@end
