//
//  FHPerson.h
//  20-runtime-消息转发的应用
//
//  Created by wangfh on 2018/8/23.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHPerson : NSObject

- (void)run;
- (void)test;
- (void)other;

@end
