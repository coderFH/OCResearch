//
//  FHCat.m
//  07-load
//
//  Created by wangfh on 2018/7/17.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHCat.h"

@implementation FHCat

+ (void)initialize {
    NSLog(@"FHCat-initialize");
}

@end
