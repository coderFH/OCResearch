//
//  FHPerson+Test1.m
//  07-load
//
//  Created by wangfh on 2018/7/17.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson+Test1.h"

@implementation FHPerson (Test1)

//+ (void)initialize {
//    NSLog(@"FHPerson(Test1)-initialize");
//}

@end
