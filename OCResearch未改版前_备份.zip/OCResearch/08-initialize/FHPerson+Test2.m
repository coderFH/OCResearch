//
//  FHPerson+Test2.m
//  07-load
//
//  Created by wangfh on 2018/7/17.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson+Test2.h"

@implementation FHPerson (Test2)

//+ (void)initialize {
//    NSLog(@"FHPerson(Test2)-initialize");
//}

@end
