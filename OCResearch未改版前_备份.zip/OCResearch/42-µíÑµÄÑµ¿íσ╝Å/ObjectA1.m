//
//  ObjectA1.m
//  42-桥接模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "ObjectA1.h"

@implementation ObjectA1

- (void)handle {
    //before 业务逻辑操作
    
    [super handle];
    
    //after 业务逻辑操作
    
}
@end
