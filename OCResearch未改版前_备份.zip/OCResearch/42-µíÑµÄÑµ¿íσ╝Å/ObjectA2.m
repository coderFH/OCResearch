//
//  ObjectA2.m
//  42-桥接模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "ObjectA2.h"

@implementation ObjectA2

@end
