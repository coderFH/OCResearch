//
//  ObjectB2.m
//  42-桥接模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "ObjectB2.h"

@implementation ObjectB2

- (void)fetchData {
    NSLog(@"第二套网络数据");
}

@end
