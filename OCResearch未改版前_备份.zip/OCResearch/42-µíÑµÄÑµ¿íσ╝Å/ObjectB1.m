//
//  ObjectB1.m
//  42-桥接模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "ObjectB1.h"

@implementation ObjectB1

- (void)fetchData {
    NSLog(@"第一套网络数据");
}

@end
