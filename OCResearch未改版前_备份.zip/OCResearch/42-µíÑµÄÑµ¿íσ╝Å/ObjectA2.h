//
//  ObjectA2.h
//  42-桥接模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "BaseObjectA.h"

NS_ASSUME_NONNULL_BEGIN

@interface ObjectA2 : BaseObjectA

@end

NS_ASSUME_NONNULL_END
