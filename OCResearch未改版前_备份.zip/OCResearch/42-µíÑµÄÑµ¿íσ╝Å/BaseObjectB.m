//
//  BaseObjectB.m
//  42-适配器模式
//
//  Created by wangfh on 2019/10/14.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "BaseObjectB.h"

@implementation BaseObjectB

- (void)fetchData {
    
}

@end
