//
//  FHDog.m
//  07-load
//
//  Created by wangfh on 2018/7/17.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHDog.h"

@implementation FHDog

+ (void)load {
    NSLog(@"FHDog-load");
}

@end
