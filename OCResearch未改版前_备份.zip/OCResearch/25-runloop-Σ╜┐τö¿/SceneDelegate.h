//
//  SceneDelegate.h
//  25-runloop-使用
//
//  Created by wangfh on 2019/10/29.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

