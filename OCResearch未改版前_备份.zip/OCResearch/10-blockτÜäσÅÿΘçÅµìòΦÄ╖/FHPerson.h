//
//  FHPerson.h
//  10-block的变量捕获
//
//  Created by wangfh on 2019/10/17.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FHPerson : NSObject

@end

NS_ASSUME_NONNULL_END
