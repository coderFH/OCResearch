//
//  FHPerson.h
//  37-内存管理-__weak原理
//
//  Created by wangfh on 2019/10/31.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FHPerson : NSObject

@end

NS_ASSUME_NONNULL_END
