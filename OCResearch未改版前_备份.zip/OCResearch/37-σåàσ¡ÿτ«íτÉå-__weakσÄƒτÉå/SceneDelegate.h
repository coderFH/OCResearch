//
//  SceneDelegate.h
//  37-内存管理-__weak原理
//
//  Created by wangfh on 2019/10/31.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

