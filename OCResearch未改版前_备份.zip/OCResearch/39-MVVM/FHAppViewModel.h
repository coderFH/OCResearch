//
//  FHAppViewModel.h
//  Interview04-MVC-Apple
//
//  Created by FH  on 2018/7/17.
//  Copyright © 2018年 FH . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FHAppViewModel : NSObject

- (instancetype)initWithController:(UIViewController *)controller;

@end
