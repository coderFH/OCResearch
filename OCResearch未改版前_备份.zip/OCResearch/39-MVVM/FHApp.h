//
//  FHApp.h
//  测试架构
//
//  Created by FH  on 2018/7/13.
//  Copyright © 2018年 FH . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHApp : NSObject
@property (copy, nonatomic) NSString *name;
@property (copy, nonatomic) NSString *image;
@end
