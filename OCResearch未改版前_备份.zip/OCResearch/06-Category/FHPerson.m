//
//  FHPerson.m
//  06-Category
//
//  Created by Ne on 2018/7/16.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson.h"

@implementation FHPerson

- (void)run {
    NSLog(@"person run");
}

@end
