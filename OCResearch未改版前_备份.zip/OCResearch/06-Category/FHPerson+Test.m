//
//  FHPerson+Test.m
//  06-Category
//
//  Created by Ne on 2018/7/16.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson+Test.h"

@implementation FHPerson (Test)

- (void)run {
    NSLog(@"person(Test) run");
}

@end
