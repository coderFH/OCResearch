//
//  FHPerson+Eat.m
//  06-Category
//
//  Created by Ne on 2018/7/16.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson+Eat.h"

@implementation FHPerson (Eat)

- (void)run {
    NSLog(@"person(Eat) run");
}

@end
