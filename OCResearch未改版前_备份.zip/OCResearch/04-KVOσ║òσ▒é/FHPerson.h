//
//  FHPerson.h
//  04-KVO
//
//  Created by wangfh on 2018/7/12.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHPerson : NSObject

@property (nonatomic,assign) int age;

@end
