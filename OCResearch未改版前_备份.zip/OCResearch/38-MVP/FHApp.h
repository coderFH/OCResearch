//
//  FHApp.h
//  38-MVP
//
//  Created by wangfh on 2018/9/27.
//  Copyright © 2018 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FHApp : NSObject

@property (copy, nonatomic) NSString *name;
@property (copy, nonatomic) NSString *image;

@end

NS_ASSUME_NONNULL_END
