//
//  MutexDemoTiaoJian.h
//  32-多线程-线程同步
//
//  Created by wangfh on 2018/8/30.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHBaseDemo.h"

@interface MutexDemoTiaoJian : FHBaseDemo

- (void)otherTest;

@end
