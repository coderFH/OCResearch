//
//  ViewController.h
//  40-重用机制的运用
//
//  Created by wangfh on 2019/10/11.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

