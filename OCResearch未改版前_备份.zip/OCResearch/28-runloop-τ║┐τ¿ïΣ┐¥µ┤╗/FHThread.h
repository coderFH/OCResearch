//
//  FHThread.h
//  28-runloop-线程保活
//
//  Created by wangfh on 2018/8/27.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHThread : NSThread

@end
