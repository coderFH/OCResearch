//
//  FHPerson.m
//  13-block-对象类型的auto变量
//
//  Created by wangfh on 2018/7/25.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson.h"

@implementation FHPerson

- (void)dealloc {
    NSLog(@"FHPerson - dealloc");
}
@end
