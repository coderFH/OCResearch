//
//  FHGoodPerson.m
//  18-runtime-msgSend
//
//  Created by wangfh on 2018/8/22.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHGoodPerson.h"

@implementation FHGoodPerson

@end
