//
//  FHCat.m
//  18-runtime-msgSend
//
//  Created by wangfh on 2018/8/23.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHCat.h"

@implementation FHCat

- (void)xiaoXiZhuanFa {
    NSLog(@"%s",__func__);
}

+ (void)leiTest {
    NSLog(@"%s",__func__);
}

- (void)leiTest {
    NSLog(@"%s",__func__);
}
@end
