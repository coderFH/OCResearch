//
//  FHPerson.h
//  18-runtime-msgSend
//
//  Created by wangfh on 2018/8/22.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHPerson : NSObject

- (void)personTest;

+ (void)dongTaiFangFa;

- (void)test;

- (void)xiaoXiZhuanFa;

+ (void)leiTest;

@end
