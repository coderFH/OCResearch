//
//  CommentCmd.m
//  45-命令模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "CommentCmd.h"

@implementation CommentCmd

- (void)execute {
    NSLog(@"评论命令");
    [super execute];
}

@end
