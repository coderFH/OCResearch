//
//  relayCmd.m
//  45-命令模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "relayCmd.h"

@implementation relayCmd

- (void)execute {
    NSLog(@"转发命令");
    [super execute];
}

@end
