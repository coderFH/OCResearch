//
//  CommentCmd.h
//  45-命令模式
//
//  Created by wangfh on 2019/10/15.
//  Copyright © 2019 wangfh. All rights reserved.
//

#import "Command.h"

NS_ASSUME_NONNULL_BEGIN

@interface CommentCmd : Command

@end

NS_ASSUME_NONNULL_END
