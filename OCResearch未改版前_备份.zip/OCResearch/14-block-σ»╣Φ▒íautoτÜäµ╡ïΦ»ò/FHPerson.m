//
//  FHPerson.m
//  14-block-对象auto的测试
//
//  Created by wangfh on 2018/7/25.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson.h"

@implementation FHPerson

- (void)dealloc {
    NSLog(@"FHPerson - dealloc");
}

@end
