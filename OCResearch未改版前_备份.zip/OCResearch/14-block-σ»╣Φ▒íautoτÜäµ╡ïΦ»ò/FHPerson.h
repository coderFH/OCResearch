//
//  FHPerson.h
//  14-block-对象auto的测试
//
//  Created by wangfh on 2018/7/25.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FHPerson : NSObject

@property (assign, nonatomic) int age;

@end
