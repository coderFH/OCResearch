//
//  FHStudent.h
//  21-runtime-super
//
//  Created by wangfh on 2018/8/23.
//  Copyright © 2018年 wangfh. All rights reserved.
//

#import "FHPerson.h"

@interface FHStudent : FHPerson

@end
